#!/usr/bin/env bash
set -euo pipefail

repo_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$repo_dir"

configs=(
  tutorials/dispim/dispim_early_fusion_mednext_s.yaml
  tutorials/dispim/dispim_siamese_mean_mednext_s.yaml
  tutorials/dispim/dispim_partial_gated_mednext_s.yaml
)

for config in "${configs[@]}"; do
  echo "Training $config"
  conda run -n pytc python scripts/main.py --config "$config" --mode train
done

