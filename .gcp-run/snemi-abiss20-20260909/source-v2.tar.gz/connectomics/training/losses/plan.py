"""Training loss-plan compilation from unified losses config."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, List, Optional, Sequence, Union

import torch.nn as nn

from ...config.pipeline.dict_utils import cfg_get as _cfg_get
from ...models.losses.metadata import (
    LossCallKind,
    LossMetadata,
    TargetKind,
    get_loss_metadata_for_module,
)
from ...utils.channel_slices import ChannelRangeSelector, normalize_channel_range_selector
from ...utils.model_outputs import resolve_head_target_slice


@dataclass(frozen=True)
class LossTermSpec:
    """Compiled loss term used by the training loss orchestrator."""

    name: str
    loss_index: int
    coefficient: float
    call_kind: LossCallKind
    target_kind: TargetKind
    pred_head: Optional[str] = None
    pred_slice: Optional[ChannelRangeSelector] = None
    pred2_head: Optional[str] = None
    target_slice: Optional[ChannelRangeSelector] = None
    pred2_slice: Optional[ChannelRangeSelector] = None
    mask_slice: Optional[ChannelRangeSelector] = None
    apply_deep_supervision: bool = True
    spatial_weight_arg: Optional[str] = None
    pos_weight: Optional[Union[float, str]] = None


def _coerce_channel_range_selector(
    value: Any,
    field_name: str,
) -> Optional[ChannelRangeSelector]:
    return normalize_channel_range_selector(value, context=field_name)


def _coerce_head_name(value: Any, field_name: str) -> Optional[str]:
    if value is None:
        return None
    if not isinstance(value, str):
        raise TypeError(f"{field_name} must be a string head name, got {type(value).__name__}.")
    normalized = value.strip()
    if not normalized:
        raise ValueError(f"{field_name} must not be empty.")
    return normalized


def compile_loss_terms_from_config(
    cfg: Any,
    loss_functions: Sequence[nn.Module],
    loss_weights: Sequence[float],
    *,
    loss_metadata: Optional[Sequence[LossMetadata]] = None,
) -> List[LossTermSpec]:
    """Compile unified ``model.loss.losses`` config to validated loss term specs.

    Each entry in ``model.loss.losses`` maps 1:1 to a loss function (by index)
    and carries its own weight, channel slices, and routing info.
    """
    model_cfg = _cfg_get(cfg, "model", None)
    loss_cfg = _cfg_get(model_cfg, "loss", None)
    losses_cfg = _cfg_get(loss_cfg, "losses", None)
    model_heads = _cfg_get(model_cfg, "heads", None) or {}
    available_head_names = set(model_heads.keys()) if hasattr(model_heads, "keys") else set()
    primary_head = _coerce_head_name(
        _cfg_get(model_cfg, "primary_head", None), "model.primary_head"
    )
    metas = (
        list(loss_metadata)
        if loss_metadata is not None
        else [get_loss_metadata_for_module(loss_fn) for loss_fn in loss_functions]
    )
    compiled: List[LossTermSpec] = []

    if losses_cfg is None:
        raise ValueError(
            "model.loss.losses is required. Configure a list of loss entries "
            "with function, weight, pred_slice, and target_slice."
        )

    losses_list = list(losses_cfg)
    if len(losses_list) != len(loss_functions):
        raise ValueError(
            f"model.loss.losses has {len(losses_list)} entries but "
            f"{len(loss_functions)} loss functions were built. These must match."
        )

    def _parse_pos_weight(
        term_cfg: Any,
        term_idx: int,
        *,
        loss_name: str,
    ) -> Optional[Union[float, str]]:
        raw = _cfg_get(term_cfg, "pos_weight", None)
        if raw is None:
            # Keep BCE-family losses unweighted by default unless explicitly set.
            # PerChannelBCEWithLogitsLoss handles its own per-channel pos_weight
            # internally, so the orchestrator must not add class balancing on top.
            if loss_name in ("WeightedBCEWithLogitsLoss", "PerChannelBCEWithLogitsLoss"):
                return 1.0
            return None
        if isinstance(raw, str):
            mode = raw.strip().lower()
            if mode != "auto":
                raise ValueError(
                    f"losses[{term_idx}] pos_weight must be a positive number "
                    f"or 'auto', got {raw!r}"
                )
            return "auto"
        value = float(raw)
        if value <= 0:
            raise ValueError(f"losses[{term_idx}] pos_weight must be > 0, got {value}")
        return value

    for term_idx, term_cfg in enumerate(losses_list):
        term_keys = set(term_cfg.keys()) if hasattr(term_cfg, "keys") else set()
        allowed_keys = {
            "function",
            "weight",
            "coefficient",
            "kwargs",
            "pred_slice",
            "pred",
            "target_slice",
            "target",
            "pred_head",
            "pred2_slice",
            "pred2",
            "pred2_head",
            "mask_slice",
            "mask",
            "call_kind",
            "call",
            "target_kind",
            "spatial_weight_arg",
            "apply_deep_supervision",
            "pos_weight",
        }
        unknown_keys = sorted(k for k in term_keys if k not in allowed_keys)
        if unknown_keys:
            keys_str = ", ".join(unknown_keys)
            raise ValueError(f"Unsupported key(s) in losses[{term_idx}]: {keys_str}")

        loss_index = term_idx  # 1:1 mapping
        base_meta = metas[loss_index]

        call_kind = str(
            _cfg_get(term_cfg, "call_kind", _cfg_get(term_cfg, "call", base_meta.call_kind))
        )
        target_kind = str(_cfg_get(term_cfg, "target_kind", base_meta.target_kind))
        spatial_weight_arg = _cfg_get(term_cfg, "spatial_weight_arg", base_meta.spatial_weight_arg)

        pred_slice = _coerce_channel_range_selector(
            _cfg_get(term_cfg, "pred_slice", _cfg_get(term_cfg, "pred", None)),
            "pred_slice",
        )
        pred_head = _coerce_head_name(_cfg_get(term_cfg, "pred_head", None), "pred_head")
        target_slice = _coerce_channel_range_selector(
            _cfg_get(term_cfg, "target_slice", _cfg_get(term_cfg, "target", None)),
            "target_slice",
        )
        pred2_head = _coerce_head_name(_cfg_get(term_cfg, "pred2_head", None), "pred2_head")
        pred2_slice = _coerce_channel_range_selector(
            _cfg_get(term_cfg, "pred2_slice", _cfg_get(term_cfg, "pred2", None)),
            "pred2_slice",
        )
        mask_slice = _coerce_channel_range_selector(
            _cfg_get(term_cfg, "mask_slice", _cfg_get(term_cfg, "mask", None)),
            "mask_slice",
        )
        resolved_pred_head = pred_head
        if resolved_pred_head is None:
            if primary_head is not None:
                resolved_pred_head = primary_head
            elif len(available_head_names) == 1:
                resolved_pred_head = next(iter(available_head_names))
        if call_kind == "pred_target" and target_slice is None and resolved_pred_head is not None:
            target_slice = _coerce_channel_range_selector(
                resolve_head_target_slice(cfg, resolved_pred_head),
                f"model.heads.{resolved_pred_head}.target_slice",
            )

        if call_kind == "unsupported":
            raise ValueError(
                f"losses[{term_idx}] uses unsupported generic loss '{base_meta.name}'. "
                "Wrap it in a custom training step path or custom loss term executor."
            )
        if call_kind not in {"pred_target", "pred_only", "pred_pred"}:
            raise ValueError(f"Unsupported call_kind {call_kind!r} in losses[{term_idx}]")

        if available_head_names:
            if pred_head is not None and pred_head not in available_head_names:
                raise ValueError(
                    f"losses[{term_idx}] pred_head={pred_head!r} is not one of the configured "
                    f"model.heads {sorted(available_head_names)}"
                )
            if pred2_head is not None and pred2_head not in available_head_names:
                raise ValueError(
                    f"losses[{term_idx}] pred2_head={pred2_head!r} is not one of the configured "
                    f"model.heads {sorted(available_head_names)}"
                )
            if pred_head is None and primary_head is None and len(available_head_names) > 1:
                raise ValueError(
                    f"losses[{term_idx}] must define pred_head or model.primary_head when "
                    f"model.heads has multiple entries {sorted(available_head_names)}"
                )
        elif pred_head is not None or pred2_head is not None:
            raise ValueError(
                f"losses[{term_idx}] uses pred_head/pred2_head but model.heads is not configured."
            )

        if call_kind == "pred_target":
            # pred_slice/target_slice default to full-channel routing when omitted.
            pass
        elif call_kind == "pred_only":
            if pred_slice is None:
                raise ValueError(f"losses[{term_idx}] pred_only terms require pred_slice")
            if target_kind != "none":
                target_kind = "none"
        elif call_kind == "pred_pred":
            if pred_slice is None or pred2_slice is None:
                raise ValueError(
                    f"losses[{term_idx}] pred_pred terms require pred_slice and pred2_slice"
                )
            if target_kind != "none":
                target_kind = "none"

        if target_kind not in {"dense", "class_index", "none"}:
            raise ValueError(f"Unsupported target_kind {target_kind!r} in losses[{term_idx}]")

        coefficient = float(
            _cfg_get(
                term_cfg, "coefficient", _cfg_get(term_cfg, "weight", loss_weights[loss_index])
            )
        )
        apply_deep_supervision = bool(_cfg_get(term_cfg, "apply_deep_supervision", True))
        pos_weight = _parse_pos_weight(
            term_cfg,
            term_idx,
            loss_name=base_meta.name,
        )
        if pos_weight is not None and spatial_weight_arg != "weight":
            raise ValueError(
                f"losses[{term_idx}] pos_weight is only supported for losses "
                f"with spatial_weight_arg='weight' (got {base_meta.name})"
            )

        compiled.append(
            LossTermSpec(
                name=f"term_{term_idx}",
                loss_index=loss_index,
                coefficient=coefficient,
                call_kind=call_kind,
                target_kind=target_kind,
                pred_head=pred_head,
                pred_slice=pred_slice,
                pred2_head=pred2_head,
                target_slice=target_slice,
                pred2_slice=pred2_slice,
                mask_slice=mask_slice,
                apply_deep_supervision=apply_deep_supervision,
                spatial_weight_arg=None if spatial_weight_arg is None else str(spatial_weight_arg),
                pos_weight=pos_weight,
            )
        )

    return compiled


def infer_num_loss_tasks_from_config(cfg: Any) -> int:
    """Infer task count for adaptive loss weighting from unified losses config.

    Each loss entry is its own task (no task_name grouping).
    """
    model_cfg = _cfg_get(cfg, "model", None)
    loss_cfg = _cfg_get(model_cfg, "loss", None)
    losses_cfg = _cfg_get(loss_cfg, "losses", None)
    if losses_cfg:
        return max(1, len(list(losses_cfg)))
    return 1


__all__ = [
    "LossTermSpec",
    "compile_loss_terms_from_config",
    "infer_num_loss_tasks_from_config",
]
