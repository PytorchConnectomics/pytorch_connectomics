"""Evaluation metric execution helpers."""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional

import torch
import torchmetrics

from ..metrics.metrics_seg import AdaptedRandError
from ..metrics.segmentation_numpy import instance_matching, instance_matching_simple, voi
from .context import EvaluationContext

logger = logging.getLogger(__name__)


_INSTANCE_INTEGER_DTYPES = tuple(
    dtype
    for dtype in (
        torch.uint8,
        torch.int8,
        torch.int16,
        torch.int32,
        torch.int64,
        getattr(torch, "uint16", None),
        getattr(torch, "uint32", None),
        getattr(torch, "uint64", None),
    )
    if dtype is not None
)


def _max_value(tensor: torch.Tensor) -> float:
    """Return a scalar max for dtypes where torch reductions may be missing."""
    if tensor.is_floating_point():
        return float(tensor.max().item())
    if tensor.dtype == torch.bool:
        return float(tensor.to(torch.uint8).max().item())
    if tensor.dtype == getattr(torch, "uint64", None):
        return float(tensor.to(torch.float64).max().item())
    return float(tensor.to(torch.int64).max().item())


def align_metric_tensors(
    pred_tensor: torch.Tensor,
    labels_tensor: torch.Tensor,
) -> tuple[Optional[torch.Tensor], Optional[torch.Tensor]]:
    pred_tensor = pred_tensor.squeeze()
    labels_tensor = labels_tensor.squeeze()

    if pred_tensor.shape == labels_tensor.shape:
        return pred_tensor, labels_tensor

    logger.warning("Shape mismatch: pred=%s, labels=%s", pred_tensor.shape, labels_tensor.shape)
    if pred_tensor.ndim == labels_tensor.ndim - 1:
        pred_tensor = pred_tensor.unsqueeze(0)
    elif labels_tensor.ndim == pred_tensor.ndim - 1:
        labels_tensor = labels_tensor.unsqueeze(0)

    if pred_tensor.shape != labels_tensor.shape:
        logger.warning(
            "Cannot compute metrics: incompatible shapes after alignment, " "pred=%s, labels=%s",
            pred_tensor.shape,
            labels_tensor.shape,
        )
        return None, None

    return pred_tensor, labels_tensor


def is_instance_segmentation(pred_tensor: torch.Tensor) -> bool:
    return pred_tensor.dtype in _INSTANCE_INTEGER_DTYPES or (
        pred_tensor.dtype == torch.float32 and _max_value(pred_tensor) > 1.0
    )


def compute_instance_metrics(
    context: EvaluationContext,
    pred_tensor: torch.Tensor,
    labels_tensor: torch.Tensor,
    volume_prefix: str,
    metrics_dict: Dict[str, Any],
    instance_iou_threshold: float,
) -> None:
    pred_instances = pred_tensor.long()
    labels_instances = labels_tensor.long()

    adapted_rand_metric = context.metric("adapted_rand")
    if context.metric_requested("adapted_rand"):
        per_volume_metric = AdaptedRandError(return_all_stats=True).to(context.device)
        per_volume_metric.update(pred_instances.cpu(), labels_instances.cpu())
        adapted_rand_value = per_volume_metric.compute()
        if isinstance(adapted_rand_value, dict):
            are_score = adapted_rand_value.get(
                "adapted_rand_error",
                adapted_rand_value.get("are", list(adapted_rand_value.values())[0]),
            )
            are_score = are_score.item() if hasattr(are_score, "item") else float(are_score)
        else:
            are_score = adapted_rand_value.item()
        logger.info("%sAdapted Rand Error: %.6f", volume_prefix, are_score)
        if isinstance(adapted_rand_value, dict):
            for k, v in adapted_rand_value.items():
                val = v.item() if hasattr(v, "item") else float(v)
                logger.info("%s  %s: %.6f", volume_prefix, k, val)

        metrics_dict["adapted_rand_error"] = are_score
        if isinstance(adapted_rand_metric, torchmetrics.Metric):
            adapted_rand_metric.update(pred_instances.cpu(), labels_instances.cpu())

    voi_metric = context.metric("voi")
    if context.metric_requested("voi"):
        split, merge = voi(pred_instances.cpu().numpy(), labels_instances.cpu().numpy())
        logger.info("%sVOI Split: %.6f", volume_prefix, split)
        logger.info("%sVOI Merge: %.6f", volume_prefix, merge)
        logger.info("%sVOI Total: %.6f", volume_prefix, split + merge)

        metrics_dict["voi_split"] = split
        metrics_dict["voi_merge"] = merge
        metrics_dict["voi_total"] = split + merge

        if isinstance(voi_metric, torchmetrics.Metric):
            voi_metric.update(pred_instances.cpu(), labels_instances.cpu())

    instance_accuracy_metric = context.metric("instance_accuracy")
    if context.metric_requested("instance_accuracy"):
        stats = instance_matching(
            labels_instances.cpu().numpy(),
            pred_instances.cpu().numpy(),
            thresh=instance_iou_threshold,
            criterion="iou",
        )
        logger.info("%sInstance Accuracy: %.6f", volume_prefix, stats["accuracy"])
        metrics_dict["instance_accuracy"] = stats["accuracy"]

        if isinstance(instance_accuracy_metric, torchmetrics.Metric):
            instance_accuracy_metric.update(pred_instances.cpu(), labels_instances.cpu())

    instance_accuracy_detail_metric = context.metric("instance_accuracy_detail")
    if context.metric_requested("instance_accuracy_detail"):
        stats_simple = instance_matching_simple(
            labels_instances.cpu().numpy(),
            pred_instances.cpu().numpy(),
            thresh=instance_iou_threshold,
            criterion="iou",
        )
        logger.info(
            "%sInstance Accuracy (Detail): %.6f [relaxed, non-Hungarian]",
            volume_prefix,
            stats_simple["accuracy"],
        )
        logger.info("%s  Precision: %.6f", volume_prefix, stats_simple["precision"])
        logger.info("%s  Recall: %.6f", volume_prefix, stats_simple["recall"])
        logger.info("%s  F1: %.6f", volume_prefix, stats_simple["f1"])

        metrics_dict["instance_accuracy_detail"] = stats_simple["accuracy"]
        metrics_dict["instance_precision_detail"] = stats_simple["precision"]
        metrics_dict["instance_recall_detail"] = stats_simple["recall"]
        metrics_dict["instance_f1_detail"] = stats_simple["f1"]

        if isinstance(instance_accuracy_detail_metric, torchmetrics.Metric):
            instance_accuracy_detail_metric.update(pred_instances.cpu(), labels_instances.cpu())


def compute_binary_metrics(
    context: EvaluationContext,
    pred_tensor: torch.Tensor,
    labels_tensor: torch.Tensor,
    volume_prefix: str,
    metrics_dict: Dict[str, Any],
    prediction_threshold: float,
) -> None:
    pred_for_threshold = pred_tensor if pred_tensor.is_floating_point() else pred_tensor.float()
    labels_for_threshold = (
        labels_tensor if labels_tensor.is_floating_point() else labels_tensor.float()
    )

    if _max_value(pred_tensor) <= 1.0:
        pred_binary = (pred_for_threshold > prediction_threshold).long()
    else:
        pred_binary = (torch.sigmoid(pred_for_threshold) > prediction_threshold).long()

    labels_binary = (
        (labels_for_threshold > prediction_threshold).long()
        if _max_value(labels_tensor) <= 1.0
        else (labels_for_threshold > 0).long()
    )

    jaccard_metric = context.metric("jaccard")
    if context.metric_requested("jaccard"):
        jaccard_value = torchmetrics.functional.jaccard_index(
            pred_binary,
            labels_binary,
            task="binary",
        )
        logger.info("%sJaccard: %.6f", volume_prefix, jaccard_value.item())
        metrics_dict["jaccard"] = jaccard_value.item()
        if jaccard_metric is not None:
            jaccard_metric.update(pred_binary.cpu(), labels_binary.cpu())

    dice_metric = context.metric("dice")
    if context.metric_requested("dice"):
        dice_value = torchmetrics.functional.dice(pred_binary, labels_binary)
        logger.info("%sDice: %.6f", volume_prefix, dice_value.item())
        metrics_dict["dice"] = dice_value.item()
        if dice_metric is not None:
            dice_metric.update(pred_binary.cpu(), labels_binary.cpu())

    accuracy_metric = context.metric("accuracy")
    if context.metric_requested("accuracy"):
        accuracy_value = torchmetrics.functional.accuracy(
            pred_binary,
            labels_binary,
            task="binary",
        )
        logger.info("%sAccuracy: %.6f", volume_prefix, accuracy_value.item())
        metrics_dict["accuracy"] = accuracy_value.item()
        if accuracy_metric is not None:
            accuracy_metric.update(pred_binary.cpu(), labels_binary.cpu())


__all__ = [
    "align_metric_tensors",
    "compute_binary_metrics",
    "compute_instance_metrics",
    "is_instance_segmentation",
]
