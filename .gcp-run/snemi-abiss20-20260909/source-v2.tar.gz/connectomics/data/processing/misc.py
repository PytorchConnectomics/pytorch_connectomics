from __future__ import annotations

from typing import List, Tuple, Union

import numpy as np


def get_seg_type(max_id: int) -> type:
    """Get optimal numpy dtype for segmentation with given max ID."""
    if max_id < 2**8:
        return np.uint8
    elif max_id < 2**16:
        return np.uint16
    elif max_id < 2**32:
        return np.uint32
    else:
        return np.uint64


def get_padsize(pad_size: Union[int, List[int]], ndim: int = 3) -> Tuple[int]:
    """Convert the padding size for 3D input volumes into numpy.pad compatible format.

    Args:
        pad_size (int, List[int]): number of values padded to the edges of each axis.
        ndim (int): the dimension of the array to be padded. Default: 3
    """
    if isinstance(pad_size, int):
        pad_size = [tuple([pad_size, pad_size]) for _ in range(ndim)]
        return tuple(pad_size)

    if len(pad_size) not in (1, ndim, 2 * ndim):
        raise ValueError(f"pad_size length must be 1, {ndim}, or {2 * ndim}, got {len(pad_size)}")
    if len(pad_size) == 1:
        pad_size = pad_size[0]
        pad_size = [tuple([pad_size, pad_size]) for _ in range(ndim)]
        return tuple(pad_size)

    if len(pad_size) == ndim:
        return tuple([tuple([x, x]) for x in pad_size])

    return tuple([tuple([pad_size[2 * i], pad_size[2 * i + 1]]) for i in range(len(pad_size) // 2)])


def array_unpad(data: np.ndarray, pad_size: Tuple[int]) -> np.ndarray:
    """Unpad a given numpy.ndarray based on the given padding size.

    Args:
        data (numpy.ndarray): the input volume to unpad.
        pad_size (tuple): number of values removed from the edges of each axis.
            Should be in the format of ((before_1, after_1), ... (before_N, after_N))
            representing the unique pad widths for each axis.
    """
    diff = data.ndim - len(pad_size)
    if diff > 0:
        extra = [(0, 0) for _ in range(diff)]
        pad_size = tuple(extra + list(pad_size))

    if len(pad_size) != data.ndim:
        raise ValueError(f"pad_size length ({len(pad_size)}) must match data.ndim ({data.ndim})")
    index = tuple([slice(pad_size[i][0], data.shape[i] - pad_size[i][1]) for i in range(data.ndim)])
    return data[index]
