from __future__ import annotations

from typing import Dict, Optional, Tuple

import cc3d
import kimimaro
import numpy as np
from scipy.ndimage import binary_fill_holes, distance_transform_edt, zoom
from skimage.filters import gaussian
from skimage.morphology import (
    ball,
    binary_erosion,
    disk,
    remove_small_holes,
)

from .bbox_processor import BBoxInstanceProcessor, BBoxProcessorConfig
from .quantize import energy_quantize

__all__ = [
    "edt_semantic",
    "edt_instance",
    "distance_transform",
    "skeleton_aware_distance_transform",
    "precompute_sdt_volume",
    "smooth_edge",
    "signed_distance_transform",
]


def edt_semantic(
    label: np.ndarray,
    mode: str = "2d",
    alpha_fore: float = 8.0,
    alpha_back: float = 50.0,
    resolution: Tuple[float, ...] = None,
):
    """Euclidean distance transform (DT or EDT) for binary semantic mask.

    Args:
        label: Binary or instance segmentation array
        mode: '2d' for slice-by-slice or '3d' for full volume
        alpha_fore: Foreground distance normalization factor
        alpha_back: Background distance normalization factor
        resolution: Voxel resolution. Default: (1.0, 1.0) for 2D, (1.0, 1.0, 1.0) for 3D
    """
    if mode not in ("2d", "3d"):
        raise ValueError(f"mode must be '2d' or '3d', got {mode!r}")
    do_2d = label.ndim == 2

    if resolution is None:
        resolution = (1.0, 1.0) if (mode == "2d" or do_2d) else (1.0, 1.0, 1.0)
    elif mode == "2d" and not do_2d and len(resolution) == 3:
        resolution = resolution[-2:]

    # Compute masks once (avoid redundant comparisons)
    fore = (label != 0).astype(np.uint8)
    back = (label == 0).astype(np.uint8)

    if mode == "3d" or do_2d:
        fore_edt = _edt_binary_mask(fore, resolution, alpha_fore)
        back_edt = _edt_binary_mask(back, resolution, alpha_back)
    else:
        # Optimized 2D mode: preallocate instead of list comprehension
        n_slices = label.shape[0]
        fore_edt = np.zeros_like(fore, dtype=np.float32)
        back_edt = np.zeros_like(back, dtype=np.float32)

        for i in range(n_slices):
            fore_edt[i] = _edt_binary_mask(fore[i], resolution, alpha_fore)
            back_edt[i] = _edt_binary_mask(back[i], resolution, alpha_back)

    distance = fore_edt - back_edt
    return np.tanh(distance)


def _edt_binary_mask(mask, resolution, alpha):
    if (mask == 1).all():  # tanh(5) = 0.99991
        return np.ones_like(mask).astype(float) * 5

    return distance_transform_edt(mask, resolution) / alpha


def edt_instance(
    label: np.ndarray,
    mode: str = "2d",
    quantize: bool = False,
    resolution: Tuple[float] = (1.0, 1.0, 1.0),
    padding: bool = False,
    erosion: int = 0,
    bg_value: float = -1.0,
):
    if mode not in ("2d", "3d"):
        raise ValueError(f"mode must be '2d' or '3d', got {mode!r}")
    if mode == "3d":
        # calculate 3d distance transform for instances
        vol_distance = distance_transform(
            label, resolution=resolution, padding=padding, erosion=erosion
        )
        if quantize:
            vol_distance = energy_quantize(vol_distance)
        return vol_distance

    # Optimized 2D mode: preallocate arrays instead of lists
    vol_distance = np.full(label.shape, bg_value, dtype=np.float32)

    # Process slices without copying (use view instead)
    for i in range(label.shape[0]):
        distance = distance_transform(
            label[i],  # No .copy() - distance_transform doesn't modify input
            padding=padding,
            erosion=erosion,
        )
        vol_distance[i] = distance

    if quantize:
        vol_distance = energy_quantize(vol_distance)

    return vol_distance


def distance_transform(
    label: np.ndarray,
    bg_value: float = -1.0,
    relabel: bool = True,
    padding: bool = False,
    resolution: Tuple[float] = (1.0, 1.0),
    erosion: int = 0,
):
    """Euclidean distance transform (EDT) for instance masks.

    Refactored to use BBoxInstanceProcessor for cleaner code and consistency.

    Args:
        label: Instance segmentation (H, W) or (D, H, W)
        bg_value: Background value for non-instance regions
        relabel: Whether to relabel connected components
        padding: Whether to pad before computing EDT
        resolution: Pixel/voxel resolution for anisotropic data
        erosion: Erosion kernel size (0 = no erosion)

    Returns:
        Normalized distance map with same shape as input
    """
    eps = 1e-6

    # Configure bbox processor
    config = BBoxProcessorConfig(
        bg_value=bg_value,
        relabel=relabel,
        padding=padding,
        pad_size=2,
        bbox_relax=1,
        combine_mode="max",
    )

    # Precompute erosion footprint (shared across instances)
    footprint = None
    if erosion > 0:
        footprint = disk(erosion) if label.ndim == 2 else ball(erosion)

    # Define per-instance EDT computation
    def compute_instance_edt(
        label_crop: np.ndarray, instance_id: int, bbox: Tuple[slice, ...], context: Dict
    ) -> Optional[np.ndarray]:
        """Compute normalized EDT for a single instance within bbox."""
        # Extract instance mask
        mask = binary_fill_holes(label_crop == instance_id)

        # Apply erosion if requested
        if context["footprint"] is not None:
            mask = binary_erosion(mask, context["footprint"])

        # Skip empty masks
        if not mask.any():
            return None

        # Compute EDT only within bbox
        boundary_edt = distance_transform_edt(mask, context["resolution"])
        edt_max = boundary_edt.max()

        if edt_max < eps:
            return None

        # Normalize and return
        energy = boundary_edt / (edt_max + eps)
        return energy * mask

    # Process all instances with bbox optimization
    processor = BBoxInstanceProcessor(config)
    return processor.process(
        label, compute_instance_edt, resolution=resolution, footprint=footprint
    )


def smooth_edge(binary, smooth_sigma: float = 2.0, smooth_threshold: float = 0.5):
    """Smooth the object contour."""
    for _ in range(2):
        binary = gaussian(binary, sigma=smooth_sigma, preserve_range=True)
        binary = (binary > smooth_threshold).astype(np.uint8)

    return binary


def signed_distance_transform(
    label: np.ndarray,
    resolution: Tuple[float] = (1.0, 1.0, 1.0),
    alpha: float = 8.0,
) -> np.ndarray:
    """Compute smooth signed distance transform for instance segmentation.

    This function produces a true signed distance transform where both foreground
    and background have meaningful gradient information, solving the class imbalance
    problem of traditional EDT approaches.

    Returns SDT in range [-1, 1]:
    - Positive values: inside instances (distance from boundary)
    - Negative values: outside instances (distance to nearest instance)
    - Zero: at instance boundaries

    Args:
        label: Instance segmentation (H, W) or (D, H, W)
        resolution: Pixel/voxel resolution for anisotropic data (z, y, x)
                   For 2D: (y, x)
                   For 3D: (z, y, x)
        alpha: Smoothness parameter for tanh normalization (default: 8.0)
               Higher values = sharper transitions at boundaries
               Lower values = smoother, more gradual transitions

    Returns:
        Signed distance transform in range [-1, 1] with same shape as input

    Example:
        >>> # 2D mitochondria segmentation
        >>> label_2d = np.array([[0, 0, 1, 1, 0],
        ...                       [0, 1, 1, 1, 0],
        ...                       [0, 0, 1, 0, 0]])
        >>> sdt_2d = signed_distance_transform(label_2d, resolution=(1.0, 1.0))
        >>> # sdt_2d will have positive values inside instance 1, negative outside

        >>> # 3D volume with anisotropic resolution
        >>> sdt_3d = signed_distance_transform(label_3d, resolution=(40, 16, 16), alpha=8.0)

    Notes:
        - This approach eliminates class imbalance by ensuring both foreground
          and background contribute meaningful gradients
        - The tanh normalization ensures smooth, bounded values suitable for
          regression with MSE loss
        - For mitochondria segmentation, typical alpha values are 6-10
    """
    # Adjust resolution for 2D vs 3D
    if label.ndim == 2:
        resolution = resolution[-2:] if len(resolution) > 2 else resolution
    elif label.ndim == 3:
        resolution = resolution if len(resolution) == 3 else (1.0, 1.0, 1.0)

    # Create binary masks
    foreground_mask = (label > 0).astype(np.uint8)
    background_mask = (label == 0).astype(np.uint8)

    # Compute EDT for both foreground and background
    if foreground_mask.any():
        foreground_edt = distance_transform_edt(foreground_mask, sampling=resolution)
    else:
        # No foreground - return all negative
        return -np.ones_like(label, dtype=np.float32)

    if background_mask.any():
        background_edt = distance_transform_edt(background_mask, sampling=resolution)
    else:
        # No background - return all positive
        return np.ones_like(label, dtype=np.float32)

    # Combine into signed distance
    # Positive inside instances, negative outside
    sdt = np.where(foreground_mask, foreground_edt, -background_edt)

    # Normalize to [-1, 1] using tanh
    # This provides smooth, bounded values suitable for regression
    sdt_normalized = np.tanh(sdt / alpha)

    return sdt_normalized.astype(np.float32)


def _thin_centerline_weight_boost(
    radius_phys: np.ndarray,
    instance_mask: np.ndarray,
    resolution: Tuple[float, ...],
    weight_param: float,
    eps: float,
) -> np.ndarray:
    """Convert local physical radius to the bounded thin-centerline boost."""
    voxel_size = max(float(min(resolution)), eps)
    r_vox = (radius_phys + eps) / voxel_size
    boost = float(weight_param) / np.maximum(1.0, r_vox)
    return (boost * instance_mask.astype(np.float32)).astype(np.float32, copy=False)


def skeleton_aware_distance_transform(
    label: np.ndarray,
    bg_value: float = -1.0,
    relabel: bool = False,
    padding: bool = False,
    resolution: Tuple[float] = (1.0, 1.0, 1.0),
    alpha: float = 0.8,
    smooth: bool = False,
    smooth_skeleton_only: bool = True,
    max_parallel: int = 1,
    weight_param: float = 0.0,
    w_base: float = 1.0,
):
    """Skeleton-based distance transform (SDT).

    Lin, Zudi, et al. "Structure-Preserving Instance Segmentation via Skeleton-Aware
    Distance Transform." International Conference on Medical Image Computing and
    Computer-Assisted Intervention. Cham: Springer Nature Switzerland, 2023.

    Uses batch kimimaro skeletonization: all instances are skeletonized in a single
    call with automatic parallelism, then per-instance EDT is computed via
    BBoxInstanceProcessor.

    Args:
        label: Instance segmentation (H, W) or (D, H, W)
        bg_value: Background value for non-instance regions
        relabel: Whether to relabel connected components
        padding: Whether to pad before computing distance
        resolution: Voxel resolution for anisotropic data (z, y, x)
        alpha: Skeleton influence exponent (higher = stronger skeleton influence)
        smooth: Whether to smooth edges before skeletonization (default False;
                adds ~20% overhead with marginal quality impact when using kimimaro)
        smooth_skeleton_only: Only smooth skeleton mask (not entire object)
        weight_param: Optional thin-centerline weight boost. Defaults to 0.0,
            which preserves the single-channel energy output.
        w_base: Base value for the optional spatial weight channel.

    Returns:
        Skeleton-aware distance map with same shape as input. When
        ``weight_param > 0``, returns ``[energy, weight]`` stacked on a leading
        channel axis.
    """
    eps = 1e-6

    # Fast-path: empty label should produce all background energy.
    if np.sum(label > 0) == 0:
        energy = np.full(label.shape, bg_value, dtype=np.float32)
        if weight_param <= 0:
            return energy
        weight = np.full(label.shape, w_base, dtype=np.float32)
        return np.stack([energy, weight], axis=0)

    # 1. Relabel outside processor so we can batch-skeletonize.
    if relabel:
        label = cc3d.connected_components(label, connectivity=6)

    # 2. Batch skeletonize all instances in one call (parallel across instances).
    #    The resulting skeleton_vertices are reused by both the energy pass and
    #    optional weight pass below; weighting does not re-skeletonize.
    skeleton_vertices = _batch_skeletonize(label, resolution, max_parallel=max_parallel)
    print(f"  Skeletonization done: {len(skeleton_vertices)} skeletons extracted")

    # 3. Per-instance EDT using BBoxProcessor (skeletons already computed).
    #    Padding coordinate offset: if padding is enabled, the processor pads the
    #    label internally, shifting coordinates by pad_size. We account for this
    #    when translating skeleton vertices to bbox-local coordinates.
    pad_offset = 2 if padding else 0

    config = BBoxProcessorConfig(
        bg_value=bg_value,
        relabel=False,  # already relabeled above
        padding=padding,
        pad_size=2,
        bbox_relax=2,
        combine_mode="max",
    )

    def compute_skeleton_edt(
        label_crop: np.ndarray, instance_id: int, bbox: Tuple[slice, ...], context: Dict
    ) -> Optional[np.ndarray]:
        """Compute skeleton-aware EDT for a single instance within bbox."""
        temp2 = remove_small_holes(label_crop == instance_id, 16, connectivity=1)
        if not temp2.any():
            return None

        binary = temp2

        # Smooth if requested
        if context["smooth"]:
            binary_smooth = smooth_edge(binary.astype(np.uint8))
            if binary_smooth.astype(int).sum() > 32:
                if context["smooth_skeleton_only"]:
                    binary = binary_smooth.astype(bool) & temp2
                else:
                    binary = binary_smooth.astype(bool)
                    temp2 = binary

        # Look up pre-computed skeleton and translate to bbox-local coordinates.
        skeleton_mask = _skeleton_vertices_to_mask(
            context["skeleton_vertices"].get(instance_id),
            label_crop.shape,
            bbox,
            context["pad_offset"],
        )

        # Fallback to regular EDT if skeletonization failed for this instance.
        if skeleton_mask is None or not skeleton_mask.any():
            boundary_edt = distance_transform_edt(temp2, context["resolution"])
            edt_max = boundary_edt.max()
            if edt_max > eps:
                energy = (boundary_edt / (edt_max + eps)) ** context["alpha"]
                return energy * temp2.astype(np.float32)
            return None

        # Compute skeleton-aware EDT
        skeleton_edt = distance_transform_edt(~skeleton_mask, context["resolution"])
        boundary_edt = distance_transform_edt(temp2, context["resolution"])

        energy = boundary_edt / (skeleton_edt + boundary_edt + eps)
        energy = energy ** context["alpha"]

        return energy * temp2.astype(np.float32)

    def compute_skeleton_boost(
        label_crop: np.ndarray, instance_id: int, bbox: Tuple[slice, ...], context: Dict
    ) -> Optional[np.ndarray]:
        """Compute the optional thin-centerline boost for a single instance."""
        temp2 = remove_small_holes(label_crop == instance_id, 16, connectivity=1)
        if not temp2.any():
            return None

        binary = temp2

        if context["smooth"]:
            binary_smooth = smooth_edge(binary.astype(np.uint8))
            if binary_smooth.astype(int).sum() > 32:
                if context["smooth_skeleton_only"]:
                    binary = binary_smooth.astype(bool) & temp2
                else:
                    binary = binary_smooth.astype(bool)
                    temp2 = binary

        skeleton_mask = _skeleton_vertices_to_mask(
            context["skeleton_vertices"].get(instance_id),
            label_crop.shape,
            bbox,
            context["pad_offset"],
        )

        if skeleton_mask is None or not skeleton_mask.any():
            boundary_edt = distance_transform_edt(temp2, context["resolution"])
            if boundary_edt.max() > eps:
                return _thin_centerline_weight_boost(
                    boundary_edt,
                    temp2,
                    context["resolution"],
                    context["weight_param"],
                    eps,
                )
            return None

        skeleton_edt = distance_transform_edt(~skeleton_mask, context["resolution"])
        boundary_edt = distance_transform_edt(temp2, context["resolution"])
        return _thin_centerline_weight_boost(
            skeleton_edt + boundary_edt,
            temp2,
            context["resolution"],
            context["weight_param"],
            eps,
        )

    processor = BBoxInstanceProcessor(config)
    energy = processor.process(
        label,
        compute_skeleton_edt,
        num_workers=max_parallel,
        skeleton_vertices=skeleton_vertices,
        pad_offset=pad_offset,
        resolution=resolution,
        alpha=alpha,
        smooth=smooth,
        smooth_skeleton_only=smooth_skeleton_only,
    )
    if weight_param <= 0:
        return energy

    weight_config = BBoxProcessorConfig(
        bg_value=0.0,
        relabel=False,
        padding=padding,
        pad_size=2,
        bbox_relax=2,
        combine_mode="max",
    )
    weight_processor = BBoxInstanceProcessor(weight_config)
    boost = weight_processor.process(
        label,
        compute_skeleton_boost,
        num_workers=max_parallel,
        skeleton_vertices=skeleton_vertices,
        pad_offset=pad_offset,
        resolution=resolution,
        weight_param=weight_param,
        smooth=smooth,
        smooth_skeleton_only=smooth_skeleton_only,
    )
    weight = w_base + boost
    return np.stack([energy, weight.astype(np.float32, copy=False)], axis=0)


def kimimaro_config(label: np.ndarray, resolution: Tuple[float, ...]) -> dict:
    """Generate kimimaro skeletonization config from data statistics.

    Derives TEASAR parameters, dust threshold, and flags from the label
    volume and its voxel resolution.  Prints the chosen config.

    The invalidation radius is ``r = scale * DBF + const`` (physical units).
    Kimimaro defaults (scale=1.5, const=300 nm) assume 16 nm XY resolution.
    We adapt ``const`` so it equals ~10 voxels at the coarsest axis, and
    ``dust_threshold`` so it skips objects smaller than a 5³-voxel cube.

    Args:
        label: Multi-label instance segmentation volume.
        resolution: Voxel resolution (z, y, x) in physical units (e.g. nm).

    Returns:
        Dict with keys ``teasar_params``, ``dust_threshold``, ``fix_branching``,
        ``fix_borders``, ``anisotropy`` — ready to pass to ``kimimaro.skeletonize``.
    """
    max_res = float(max(resolution))
    min_res = float(min(resolution))
    aniso_ratio = max_res / min_res if min_res > 0 else 1.0
    n_instances = len(np.unique(label)) - 1  # exclude background
    voxel_vol = float(np.prod(resolution))  # physical volume per voxel

    # --- TEASAR params ---
    # const: minimum invalidation radius.  ~10 voxels at the coarsest axis
    #   ensures small processes are still invalidated in one pass.
    const = max(max_res * 10, 100.0)
    # scale: multiplier on distance-from-boundary.  1.5 is robust across
    #   neurite widths; values >2 over-invalidate thin processes.
    scale = 1.5
    # pdrf_exponent: power-of-2 → minor speedup.  4 is the sweet spot:
    #   pushes paths toward medial axis without over-penalizing cavities.
    pdrf_exponent = 4
    # pdrf_scale: large value so penalty dominates geodesic distance.
    pdrf_scale = 100000

    teasar_params = {
        "scale": scale,
        "const": const,
        "pdrf_scale": pdrf_scale,
        "pdrf_exponent": pdrf_exponent,
        # Disable soma detection (not needed for SDT).
        "soma_acceptance_threshold": 1e9,
        "soma_detection_threshold": 1e9,
        "soma_invalidation_const": 0,
        "soma_invalidation_scale": 0,
    }

    # --- dust threshold ---
    # Skip instances smaller than a 5³-voxel cube.
    dust_threshold = max(5**label.ndim, 5)

    # --- flags ---
    # fix_branching: improves branch-point accuracy but ~1.3x slower.
    #   Not needed for SDT where approximate medial axis suffices.
    # fix_borders: ensures deterministic skeleton endpoints at volume
    #   boundaries for chunk stitching.  Not needed for SDT.
    config = {
        "teasar_params": teasar_params,
        "dust_threshold": dust_threshold,
        "fix_branching": False,
        "fix_borders": False,
        "anisotropy": tuple(float(r) for r in resolution),
    }

    print(
        f"  kimimaro config: {n_instances} instances, "
        f"anisotropy={config['anisotropy']} (ratio {aniso_ratio:.1f}x), "
        f"const={const:.0f}, dust={dust_threshold}"
    )

    return config


def _batch_skeletonize(
    label: np.ndarray, resolution: Tuple[float, ...], max_parallel: int = 1
) -> Dict[int, np.ndarray]:
    """Skeletonize all instances in one kimimaro call (map-reduce over labels).

    A single ``kimimaro.skeletonize`` call computes connected components and the
    full-volume distance field (``edtfn``) ONCE for every instance, then runs
    per-object TEASAR. ``max_parallel > 1`` uses kimimaro's native parallelism:
    ``cc_labels`` is mirrored once into ``/dev/shm`` and the per-object TEASAR is
    distributed across subprocesses. So the expensive format/CC/EDT passes are paid
    once and only the embarrassingly-parallel per-object skeletonization fans out —
    unlike a per-instance approach, which recomputes the full-volume EDT for every
    giant neuron whose bbox spans the volume.

    Args:
        label: Multi-label volume (each non-zero value is an instance).
        resolution: Voxel resolution (z, y, x).
        max_parallel: kimimaro subprocess count (1 = serial; <=0 = all cores).

    Returns:
        Dict mapping instance_id → (N, ndim) int array of vertex coordinates
        in the input label's coordinate system.
    """
    n_instances = int(label.max())
    use_progress = n_instances > 50
    config = kimimaro_config(label, resolution)
    parallel = int(max_parallel)
    # chunk_size=1 forces kimimaro's dynamic per-object scheduling (uimap) so a few
    # giant neurons distribute across workers instead of statically clumping onto a
    # handful (the default 100 would underutilize a 64-core node for ~hundreds of
    # objects). Only consulted when parallel != 1.
    parallel_chunk_size = 1

    try:
        skeletons = kimimaro.skeletonize(
            label,
            teasar_params=config["teasar_params"],
            anisotropy=config["anisotropy"],
            dust_threshold=config["dust_threshold"],
            fix_branching=config["fix_branching"],
            fix_borders=config["fix_borders"],
            parallel=parallel,
            parallel_chunk_size=parallel_chunk_size,
            progress=use_progress,
        )
    except Exception as e:
        print(f"  kimimaro failed: {e}")
        return {}

    # kimimaro returns vertices in physical coordinates (scaled by anisotropy).
    # Convert back to voxel indices by dividing by resolution.
    anisotropy = np.array(config["anisotropy"], dtype=np.float64)
    result = {}
    for inst_id, skel in skeletons.items():
        if len(skel.vertices) > 0:
            result[inst_id] = (skel.vertices / anisotropy).astype(int)
    return result


def _skeleton_vertices_to_mask(
    vertices: Optional[np.ndarray],
    crop_shape: Tuple[int, ...],
    bbox: Tuple[slice, ...],
    pad_offset: int,
) -> Optional[np.ndarray]:
    """Convert skeleton vertices (full-volume coords) to a binary mask in bbox-local coords.

    Args:
        vertices: (N, ndim) vertex coordinates in the original (unpadded) label space,
                  or None if this instance had no skeleton.
        crop_shape: Shape of the bbox crop.
        bbox: Tuple of slices defining the bbox in the (possibly padded) label.
        pad_offset: Coordinate offset added by padding (0 if no padding).
    """
    if vertices is None or len(vertices) == 0:
        return None

    # Translate: original-label coords → padded-label coords → bbox-local coords.
    bbox_origin = np.array([s.start for s in bbox])
    local_verts = vertices + pad_offset - bbox_origin

    # Filter to valid range.
    valid = np.all((local_verts >= 0) & (local_verts < np.array(crop_shape)), axis=1)
    local_verts = local_verts[valid]

    if len(local_verts) == 0:
        return None

    mask = np.zeros(crop_shape, dtype=bool)
    if len(crop_shape) == 3:
        mask[local_verts[:, 0], local_verts[:, 1], local_verts[:, 2]] = True
    else:
        mask[local_verts[:, 0], local_verts[:, 1]] = True
    return mask


def precompute_sdt_volume(
    label_path: str,
    output_path: str,
    resolution: Tuple[float, ...] = (1.0, 1.0, 1.0),
    alpha: float = 0.8,
    bg_value: float = -1.0,
) -> str:
    """Precompute skeleton-aware distance transform on a full label volume.

    Computes the SDT once on the entire volume and saves to HDF5.
    Subsequent training runs load the precomputed result, avoiding
    the expensive per-crop skeletonization.

    Args:
        label_path: Path to the instance segmentation label volume.
        output_path: Path to save the precomputed SDT (HDF5).
        resolution: Voxel resolution (z, y, x) for anisotropic data.
        alpha: Skeleton influence exponent.
        bg_value: Background value for non-instance regions.

    Returns:
        The output_path (for chaining).
    """
    import os as _os
    import time
    from pathlib import Path

    from ..io.io import read_volume, save_volume

    print(f"Precomputing SDT: {label_path} → {output_path}")
    if ".zarr" in output_path:
        zarr_idx = output_path.index(".zarr")
        Path(output_path[: zarr_idx + 5]).parent.mkdir(parents=True, exist_ok=True)
    else:
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)

    label = read_volume(label_path)
    n_inst = len(np.unique(label)) - 1
    parallel = min(4, _os.cpu_count() or 1)
    print(f"  Label shape: {label.shape}, instances: {n_inst}, parallel: {parallel}")
    print(f"  One-time computation (may take minutes for large volumes)...", flush=True)

    t0 = time.time()
    sdt = skeleton_aware_distance_transform(
        label,
        resolution=resolution,
        alpha=alpha,
        bg_value=bg_value,
        max_parallel=parallel,
    )
    elapsed = time.time() - t0
    print(f"  SDT computed in {elapsed:.1f}s, range: [{sdt.min():.3f}, {sdt.max():.3f}]")

    save_volume(output_path, sdt)
    print(f"  Saved to {output_path}")

    return output_path


def precompute_skeleton_volume(
    label_path: str,
    output_path: str,
    resolution: Tuple[float, ...] = (1.0, 1.0, 1.0),
    num_workers: int = 1,
    downsample_xy: int = 1,
) -> str:
    """Precompute kimimaro skeletons and rasterize into a label-like volume.

    Each skeleton voxel stores its instance ID; background is 0.
    This volume can be loaded as ``label_aux`` and flows through spatial
    transforms with nearest-neighbor interpolation (preserving discrete IDs).
    EDT is then computed cheaply per crop during training.

    Args:
        label_path: Path to the instance segmentation label volume.
        output_path: Path to save the skeleton volume (HDF5).
        resolution: Voxel resolution (z, y, x) in physical units.
        num_workers: Processes for label-parallel skeletonization (>1 spreads the
            per-instance TEASAR work across CPUs; output is identical to serial).
        downsample_xy: Skeletonize on the label strided-subsampled by this factor
            on the two fine (first two) axes, then upscale vertices back. TEASAR
            cost scales ~quadratically with XY size, so 2x ≈ 5x faster (measured)
            and also shrinks the distance field so it fits cache (relieving the
            parallel memory-bandwidth wall). The medial axis is robust to 2x; the
            rasterized skeleton is re-EDT'd downstream so vertex density matters
            little. The output skeleton volume is always at full resolution.

    Returns:
        The output_path.
    """
    import time
    from pathlib import Path

    from ..io.io import read_volume, save_volume

    print(f"Precomputing skeleton volume: {label_path} → {output_path}")
    if ".zarr" in output_path:
        zarr_idx = output_path.index(".zarr")
        Path(output_path[: zarr_idx + 5]).parent.mkdir(parents=True, exist_ok=True)
    else:
        Path(output_path).parent.mkdir(parents=True, exist_ok=True)

    label = read_volume(label_path)
    n_inst = len(np.unique(label)) - 1
    print(f"  Label shape: {label.shape}, instances: {n_inst}")
    print(f"  One-time computation...", flush=True)

    f = int(downsample_xy)
    if f > 1:
        skel_label = label[::f, ::f]  # subsample the two fine axes; axis 2 (coarse Z) kept
        skel_res = (resolution[0] * f, resolution[1] * f) + tuple(resolution[2:])
        print(f"  Downsample XY {f}x for skeletonization: {skel_label.shape} @ {skel_res}", flush=True)
    else:
        skel_label, skel_res = label, resolution

    t0 = time.time()
    skeleton_vertices = _batch_skeletonize(skel_label, skel_res, max_parallel=num_workers)
    elapsed_skel = time.time() - t0
    print(f"  Skeletonization done in {elapsed_skel:.1f}s: {len(skeleton_vertices)} skeletons")

    if f > 1:
        # Upscale vertices on the two subsampled axes back to full-res voxel coords.
        for inst_id, verts in skeleton_vertices.items():
            verts[:, 0] *= f
            verts[:, 1] *= f

    # Rasterize: skeleton volume with instance IDs.
    skel_vol = np.zeros(label.shape, dtype=label.dtype)
    for inst_id, verts in skeleton_vertices.items():
        valid = np.all((verts >= 0) & (verts < np.array(label.shape)), axis=1)
        verts = verts[valid]
        if len(verts) > 0:
            if label.ndim == 3:
                skel_vol[verts[:, 0], verts[:, 1], verts[:, 2]] = inst_id
            else:
                skel_vol[verts[:, 0], verts[:, 1]] = inst_id

    n_skel_voxels = int((skel_vol > 0).sum())
    print(
        f"  Skeleton volume: {n_skel_voxels} voxels ({n_skel_voxels / max(skel_vol.size, 1) * 100:.2f}%)"
    )

    save_volume(output_path, skel_vol)
    print(f"  Saved to {output_path}")

    return output_path


def _maxpool(mask: np.ndarray, factor: int, axes: Tuple[int, int]) -> np.ndarray:
    """Boolean max-pool by ``factor`` along selected axes, padding with False."""
    if factor < 1:
        raise ValueError(f"factor must be >= 1, got {factor}")
    if len(axes) != 2 or len(set(axes)) != 2:
        raise ValueError(f"axes must contain two unique axes, got {axes!r}")

    pooled = np.asarray(mask, dtype=bool)
    if factor == 1:
        return pooled.copy()

    for axis in axes:
        if axis < 0 or axis >= pooled.ndim:
            raise ValueError(f"axis {axis} out of bounds for ndim={pooled.ndim}")

    pad_width = [(0, 0)] * pooled.ndim
    for axis in axes:
        remainder = pooled.shape[axis] % factor
        if remainder:
            pad_width[axis] = (0, factor - remainder)
    if any(after for _, after in pad_width):
        pooled = np.pad(pooled, pad_width, mode="constant", constant_values=False)

    for axis in sorted(axes):
        shape = pooled.shape
        reshaped = (
            shape[:axis]
            + (shape[axis] // factor, factor)
            + shape[axis + 1 :]
        )
        pooled = pooled.reshape(reshaped).max(axis=axis + 1)
    return pooled


def _resolve_downsample_axes(
    resolution: Tuple[float, ...],
    downsample_axes: Optional[Tuple[int, int]],
) -> Tuple[int, int]:
    if downsample_axes is not None:
        axes = tuple(int(axis) for axis in downsample_axes)
        if len(axes) != 2 or len(set(axes)) != 2:
            raise ValueError(
                f"downsample_axes must contain two unique axes, got {downsample_axes!r}"
            )
        if any(axis < 0 or axis >= 3 for axis in axes):
            raise ValueError(f"downsample_axes must be within 3D axes, got {downsample_axes!r}")
        return axes

    if len(resolution) != 3:
        raise ValueError(f"3D EDT downsampling requires 3 resolution values, got {resolution!r}")
    return tuple(sorted(range(3), key=lambda axis: (float(resolution[axis]), axis))[:2])


def _resize_ratio_to_shape(ratio_ds: np.ndarray, shape: Tuple[int, ...]) -> np.ndarray:
    zoom_factors = tuple(float(dst) / float(src) for dst, src in zip(shape, ratio_ds.shape))
    try:
        ratio = zoom(
            ratio_ds,
            zoom_factors,
            order=1,
            mode="nearest",
            grid_mode=True,
            prefilter=False,
        )
    except TypeError:
        from skimage.transform import resize

        ratio = resize(
            ratio_ds,
            shape,
            order=1,
            mode="edge",
            anti_aliasing=False,
            preserve_range=True,
        )

    if ratio.shape != shape:
        from skimage.transform import resize

        ratio = resize(
            ratio_ds,
            shape,
            order=1,
            mode="edge",
            anti_aliasing=False,
            preserve_range=True,
        )
    if ratio.shape != shape:
        raise RuntimeError(f"downsampled EDT upsample produced {ratio.shape}, expected {shape}")
    return ratio.astype(np.float32, copy=False)


def _downsampled_skeleton_aware_edt(
    temp2: np.ndarray,
    skeleton_mask: np.ndarray,
    resolution: Tuple[float, ...],
    alpha: float,
    eps: float,
    factor: int,
    axes: Tuple[int, int],
) -> Optional[np.ndarray]:
    """Approximate giant-instance SDT from coarse EDTs and a full-res foreground mask.

    For a giant crop with V voxels and downsampling factor f on two axes, coarse
    EDTs are roughly ``2 * 8 * V / f**2`` bytes. The full-res phase keeps the
    upsampled ratio as float32 and applies the power/mask in-place, so the
    dominant temporary is roughly one float32 full-res buffer plus ``temp2``.
    """
    sk_src = skeleton_mask & temp2
    fg = _maxpool(temp2, factor, axes)
    sk = _maxpool(sk_src, factor, axes)
    if not np.all(fg[sk]):
        raise RuntimeError("downsampled skeleton mask is not contained by foreground mask")

    res_ds = list(float(value) for value in resolution)
    for axis in axes:
        res_ds[axis] *= factor
    res_ds_tuple = tuple(res_ds)

    boundary_edt = distance_transform_edt(fg, res_ds_tuple)
    if sk.any():
        skeleton_edt = distance_transform_edt(~sk, res_ds_tuple)
        np.add(skeleton_edt, boundary_edt, out=skeleton_edt)
        skeleton_edt += eps
        np.divide(boundary_edt, skeleton_edt, out=boundary_edt)
        del skeleton_edt
    else:
        edt_max = float(boundary_edt.max())
        if edt_max <= eps:
            return None
        boundary_edt /= edt_max + eps
    del fg, sk, sk_src

    ratio = _resize_ratio_to_shape(boundary_edt.astype(np.float32), temp2.shape)
    del boundary_edt
    np.power(ratio, alpha, out=ratio)
    ratio *= temp2
    return ratio


def skeleton_aware_edt_from_skeleton_vol(
    label: np.ndarray,
    skeleton_vol: np.ndarray,
    resolution: Tuple[float, ...] = (1.0, 1.0, 1.0),
    alpha: float = 0.8,
    bg_value: float = -1.0,
    weight_param: float = 0.0,
    w_base: float = 1.0,
    max_parallel: int = 0,
    edt_downsample_threshold: int = 0,
    edt_downsample_factor: int = 2,
    downsample_axes: Optional[Tuple[int, int]] = None,
    max_concurrent_giants: int = 0,
) -> np.ndarray:
    """Compute skeleton-aware EDT using a precomputed skeleton volume.

    Skips kimimaro entirely — extracts per-instance skeleton masks from
    ``skeleton_vol`` and computes EDT per instance.  Fast enough for
    per-crop use during training.

    Args:
        label: Instance segmentation crop (D, H, W) or (H, W).
        skeleton_vol: Skeleton volume crop (same shape), where each
            skeleton voxel stores its instance ID, background is 0.
        resolution: Voxel resolution for anisotropic EDT.
        alpha: Skeleton influence exponent.
        bg_value: Background fill value.
        weight_param: Optional thin-centerline weight boost. Defaults to 0.0,
            which preserves the single-channel energy output.
        w_base: Base value for the optional spatial weight channel.
        max_parallel: Threads for the per-instance EDT (0 = serial). For
            whole-volume/slab precompute this should be the CPU count — the
            per-instance ``distance_transform_edt`` calls are the cost and a few
            giant neurons (full-slab bbox) otherwise serialize the whole band.
        edt_downsample_threshold: Crop-size threshold in voxels for approximate
            giant-instance EDT downsampling. ``0`` disables downsampling and keeps
            the exact float64 path.
        edt_downsample_factor: Downsample factor applied to two axes for giant
            instances.
        downsample_axes: Optional pair of axes to downsample. When omitted, the
            two finest physical-resolution axes are chosen.
        max_concurrent_giants: Optional semaphore cap for concurrent giant EDT
            work. ``0`` leaves giant concurrency unbounded.

    Returns:
        Skeleton-aware distance map, same shape as label. When
        ``weight_param > 0``, returns ``[energy, weight]`` stacked on a leading
        channel axis.
    """
    eps = 1e-6
    downsample_enabled = int(edt_downsample_threshold) > 0

    if downsample_enabled and weight_param > 0:
        raise NotImplementedError(
            "edt_downsample_threshold with weight_param > 0 is not implemented; "
            "disable downsampling for weighted SDT."
        )
    if downsample_enabled and int(edt_downsample_factor) < 2:
        raise ValueError("edt_downsample_factor must be >= 2 when EDT downsampling is enabled")
    if int(max_concurrent_giants) < 0:
        raise ValueError("max_concurrent_giants must be >= 0")
    resolved_downsample_axes = None
    if downsample_enabled and label.ndim == 3:
        resolved_downsample_axes = _resolve_downsample_axes(tuple(resolution), downsample_axes)

    if np.sum(label > 0) == 0:
        energy = np.full(label.shape, bg_value, dtype=np.float32)
        if weight_param <= 0:
            return energy
        weight = np.full(label.shape, w_base, dtype=np.float32)
        return np.stack([energy, weight], axis=0)

    config = BBoxProcessorConfig(
        bg_value=bg_value,
        relabel=False,
        padding=False,
        pad_size=2,
        bbox_relax=2,
        combine_mode="max",
    )

    def compute_edt_with_skeleton(
        label_crop: np.ndarray, instance_id: int, bbox: Tuple[slice, ...], context: Dict
    ) -> Optional[np.ndarray]:
        temp2 = remove_small_holes(label_crop == instance_id, 16, connectivity=1)
        if not temp2.any():
            return None

        # Extract skeleton mask from precomputed skeleton volume crop.
        skel_crop = context["skeleton_vol"][bbox]
        skeleton_mask = skel_crop == instance_id

        giant_path = (
            context["edt_downsample_threshold"] > 0
            and label_crop.ndim == 3
            and temp2.size > context["edt_downsample_threshold"]
        )
        if giant_path:
            with context["downsampled_lock"]:
                context["downsampled_ids"].append(instance_id)
            semaphore = context["giant_semaphore"]
            if semaphore is None:
                return _downsampled_skeleton_aware_edt(
                    temp2,
                    skeleton_mask,
                    context["resolution"],
                    context["alpha"],
                    eps,
                    context["edt_downsample_factor"],
                    context["downsample_axes"],
                )
            with semaphore:
                return _downsampled_skeleton_aware_edt(
                    temp2,
                    skeleton_mask,
                    context["resolution"],
                    context["alpha"],
                    eps,
                    context["edt_downsample_factor"],
                    context["downsample_axes"],
                )

        if not skeleton_mask.any():
            # Fallback: regular EDT without skeleton.
            boundary_edt = distance_transform_edt(temp2, context["resolution"])
            edt_max = boundary_edt.max()
            if edt_max > eps:
                energy = (boundary_edt / (edt_max + eps)) ** context["alpha"]
                return energy * temp2.astype(np.float32)
            return None

        skeleton_edt = distance_transform_edt(~skeleton_mask, context["resolution"])
        boundary_edt = distance_transform_edt(temp2, context["resolution"])

        energy = boundary_edt / (skeleton_edt + boundary_edt + eps)
        energy = energy ** context["alpha"]
        return energy * temp2.astype(np.float32)

    def compute_skeleton_boost(
        label_crop: np.ndarray, instance_id: int, bbox: Tuple[slice, ...], context: Dict
    ) -> Optional[np.ndarray]:
        temp2 = remove_small_holes(label_crop == instance_id, 16, connectivity=1)
        if not temp2.any():
            return None

        skel_crop = context["skeleton_vol"][bbox]
        skeleton_mask = skel_crop == instance_id

        if not skeleton_mask.any():
            boundary_edt = distance_transform_edt(temp2, context["resolution"])
            if boundary_edt.max() > eps:
                return _thin_centerline_weight_boost(
                    boundary_edt,
                    temp2,
                    context["resolution"],
                    context["weight_param"],
                    eps,
                )
            return None

        skeleton_edt = distance_transform_edt(~skeleton_mask, context["resolution"])
        boundary_edt = distance_transform_edt(temp2, context["resolution"])
        return _thin_centerline_weight_boost(
            skeleton_edt + boundary_edt,
            temp2,
            context["resolution"],
            context["weight_param"],
            eps,
        )

    downsampled_ids = []
    downsampled_lock = None
    giant_semaphore = None
    if downsample_enabled:
        import threading

        downsampled_lock = threading.Lock()
        if max_concurrent_giants > 0:
            giant_semaphore = threading.Semaphore(int(max_concurrent_giants))

    processor = BBoxInstanceProcessor(config)
    energy = processor.process(
        label,
        compute_edt_with_skeleton,
        num_workers=max_parallel,
        skeleton_vol=skeleton_vol,
        resolution=resolution,
        alpha=alpha,
        edt_downsample_threshold=int(edt_downsample_threshold),
        edt_downsample_factor=int(edt_downsample_factor),
        downsample_axes=resolved_downsample_axes,
        downsampled_ids=downsampled_ids,
        downsampled_lock=downsampled_lock,
        giant_semaphore=giant_semaphore,
    )
    if downsampled_ids:
        missing = [
            instance_id
            for instance_id in sorted(set(downsampled_ids))
            if not np.any((label == instance_id) & (energy > 0))
        ]
        if missing:
            raise RuntimeError(
                "Downsampled SDT failed to write positive output for instance ids "
                f"{missing[:10]}{'...' if len(missing) > 10 else ''}"
            )
    if downsample_enabled:
        n_downsampled = len(set(downsampled_ids))
        print(
            "  EDT downsampled instances: "
            f"{n_downsampled} threshold={int(edt_downsample_threshold)} "
            f"factor={int(edt_downsample_factor)} axes={resolved_downsample_axes} "
            f"max_concurrent_giants={int(max_concurrent_giants)}",
            flush=True,
        )
    if weight_param <= 0:
        return energy

    weight_config = BBoxProcessorConfig(
        bg_value=0.0,
        relabel=False,
        padding=False,
        pad_size=2,
        bbox_relax=2,
        combine_mode="max",
    )
    weight_processor = BBoxInstanceProcessor(weight_config)
    boost = weight_processor.process(
        label,
        compute_skeleton_boost,
        num_workers=max_parallel,
        skeleton_vol=skeleton_vol,
        resolution=resolution,
        weight_param=weight_param,
    )
    weight = w_base + boost
    return np.stack([energy, weight.astype(np.float32, copy=False)], axis=0)


def sdt_path_for_label(
    label_path: str,
    mode: str = "sdt",
    cache_dir: Optional[str] = None,
) -> str:
    """Derive the precomputed cache path from a label file path.

    HDF5 labels produce sibling ``*.h5`` cache files. Zarr dataset paths such
    as ``data.zarr/seg`` produce sibling arrays inside the same store, for
    example ``data.zarr/seg_skeleton``. A bare ``data.zarr`` label path falls
    back to a sibling store such as ``data_skeleton.zarr``.

    Args:
        mode: ``"sdt"`` for full SDT, ``"skeleton"`` for skeleton volume.
        cache_dir: Optional directory where cache files should be written.
            When set, the cache filename is derived from the label basename
            instead of being written beside the source label.
    """
    import os

    if ".zarr" in label_path:
        zarr_idx = label_path.index(".zarr")
        zarr_path = label_path[: zarr_idx + 5]
        sub_key = label_path[zarr_idx + 5 :].strip("/")
        if cache_dir:
            zarr_name = os.path.basename(zarr_path)
            if sub_key:
                return os.path.join(cache_dir, zarr_name, f"{sub_key}_{mode}")
            base = os.path.splitext(zarr_name)[0]
            return os.path.join(cache_dir, f"{base}_{mode}.zarr")
        if sub_key:
            return f"{zarr_path}/{sub_key}_{mode}"
        base = zarr_path[: -len(".zarr")]
        return f"{base}_{mode}.zarr"

    if cache_dir:
        base = os.path.splitext(os.path.basename(label_path))[0]
        return os.path.join(cache_dir, f"{base}_{mode}.h5")

    base, _ = os.path.splitext(label_path)
    return base + f"_{mode}.h5"
